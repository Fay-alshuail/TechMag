<?php


$hostname='fixmin.com';
$username_db='fixmin_db';
$password_db='!m[s3LrAE3nw';

$conn = mysql_connect($hostname, $username_db,$password_db);
$db = mysql_select_db('fixmin',$conn)

 ?>
