SELECT * FROM `طلب الصيانة` WHERE `بريد_الفني`='tahanihak.gmail.com' and `حالة_الطلب`='مقبول'
