
<html>
	<head>
		<title>خدمة العملاء</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-whidth", user-scalable=no, initial-scale=1.0>
        <meta http-equiv="X-UA-Comptible" content="ie=edge">
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="../assets/css/style.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>


		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Intro -->
							<section id="intro" class="wrapper style1 fullscreen fade-up">
								<div class="inner" >
									<h2>الوصول السريع</h2>
									<section>
										<table style="width:100% text-align:center ">
			<tr>
				<th><center><a href="#two"><h3>إعدادات</h3><img src="setting.png" width="100" height="100"></a></center></th>
				<th><center><a href="#one"><h3>الطلبات</h3><img src="fix.png" width="100" height="100"></a></center></th>

			</tr>
		</table>
		</section>
		</div>
							</section>

							<!-- One -->
									<section id="one" class="wrapper style2 spotlights">
											<div class="inner"  >
												<h2>الطلبات</h2>
												<section>
													<table style="width:100% text-align:center ">
			      <tr>
							<th><center><a href="accept.php"><h3>الطلبات المقبولة</h3><img src="accept.png" width="100" height="100"></a></center></th>
							<th><center><a href="problems.php"><h3>الطلبات المستلمة</h3><img src="arrived.png" width="100" height="100"></a></center></th>
			      </tr>
			    </table>
				</div>
			</section>

											<section id="two" class="wrapper style5 fade-up">
												<div class="inner">
													<h2>الإعدادات </h2>
													<section style="text-align=right">

															<table style="width:70% text-align:center ">
								<tr>
									<th><center><a href="setting.php"><h3>تعديل البيانات الشخصية</h3><img src="setting.png" width="100" height="100"></a></center></th>
								</tr>
							</table>
						</section>
						</div>
											</section>

</div>
</body>
